// JavaScript Document

 function reloadgrid(){
	 var t=window.t;
	  $$(t+'grid').clearAll();
	  $$(t+'grid').load("./p/gridfile.php?id="+t,"xml");
	  
	}




	